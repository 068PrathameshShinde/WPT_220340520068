
const express = require('express');
const app = express();
const cors = require('cors');

const mysql=require('mysql2');
const {respone}= require('express');
app.use(cors());

JSON.stringify(result)

const connection=mysql.createConnection({
	host:'localhost',
	user:'pratham',
	password:'cdac',
	database:'pune',
	port:3306
});

app.get('/read',function(req,res){

	const {bookid}=req.body
	const statement=`select * from book where bookid = ?`

	connection.query(statement,[bookid],(error,res) =>{
		if(error){
			res.send(error)
		}
		else
		{
			res.send(res)
		}
	})
});


app.listen(8081, function () {
    console.log("server listening at port 8081...");
});